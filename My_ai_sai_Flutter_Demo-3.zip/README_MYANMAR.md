# My ai sai — Flutter Demo Prototype

ဒီ project သည် Android အတွက် UI/demo prototype ဖြစ်သည်။ AI video generation, text-to-speech, speech-to-text, server-side watermarking, account/login, subscription enforcement နှင့် KPay automatic payment verification တို့ကို backend/API မချိတ်ဆက်ရသေးပါ။

## လိုအပ်ချက်
- Flutter SDK
- Android SDK / Android Studio
- Android ဖုန်းတွင် build လုပ်ရန် cloud build service သို့မဟုတ် PC/Android development environment လိုနိုင်သည်။
- ဖုန်းတစ်လုံးတည်းနဲ့လုပ်မည်ဆိုလျှင် browser-based Flutter IDE/cloud build service ကို သုံးနိုင်သော်လည်း service တစ်ခုချင်းစီ၏ ကန့်သတ်ချက်ရှိနိုင်သည်။

## Run / Build
1. Flutter project ကို computer သို့မဟုတ် Flutter-support လုပ်သော cloud IDE ထဲတွင် ဖွင့်ပါ။
2. Terminal တွင်:
   ```bash
   flutter pub get
   flutter run
   ```
3. APK ထုတ်ရန်:
   ```bash
   flutter build apk --release
   ```
4. APK သည် `build/app/outputs/flutter-apk/app-release.apk` တွင် ရှိမည်။

## ဒီ demo ထဲမှာ
- My ai sai dark UI
- Image picker (gallery မှ ဓာတ်ပုံရွေးနိုင်)
- Text-to-Voice / Voice-to-Text demo action messages
- Pro plan cards
- KPay/Viber contact details
- Plan request status message

## Production version အတွက် လိုအပ်သော backend
- Authentication: Firebase Auth သို့မဟုတ် အခြား secure authentication
- Database: user plan, subscription expiry, daily usage counters
- Storage: uploaded images, generated audio/video
- AI providers: image-to-video API, text-to-speech API, speech-to-text API
- Video processing: server-side watermark overlay `My ai sai`
- Payment verification: KPay ၏ တရားဝင် merchant/API integration ရရှိနိုင်မှုကို provider ထံ အတည်ပြုပါ။ Official API မရှိလျှင် screenshot သို့မဟုတ် transfer notification ကို အလိုအလျောက် ယုံကြည်ပြီး activate မလုပ်ပါနှင့်။ Admin review flow သုံးပါ။
- Server-side limit enforcement: 1-month plan = 30,000 MMK, 5 videos/day, 11 seconds each; 2-month plan = 50,000 MMK, 6 videos/day, 20 seconds each.
- Do not put AI API secrets or payment credentials inside the Android APK. Keep secrets on the backend.

## အရေးကြီး
ဒီ demo သည် payment ကို မလက်ခံပါ၊ KPay ကို မစစ်ဆေးပါ၊ အခပေး plan ကို အမှန်တကယ် activate မလုပ်ပါ။ Production မတင်မီ security, privacy policy, terms, provider pricing and API permissions စစ်ဆေးပါ။
