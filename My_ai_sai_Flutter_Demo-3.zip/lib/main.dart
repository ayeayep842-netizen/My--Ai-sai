import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const MyAiSaiApp());

class MyAiSaiApp extends StatelessWidget {
  const MyAiSaiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My ai sai',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF080D1B),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF16C8FF),
          secondary: Color(0xFFB44CFF),
          surface: Color(0xFF121B31),
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF121B31),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final picker = ImagePicker();
  XFile? image;
  final textController = TextEditingController();
  String status = 'Demo mode — AI services are not connected.';
  String plan = 'Free Demo';
  int videosToday = 0;

  Future<void> chooseImage() async {
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) setState(() => image = picked);
  }

  void demoAction(String feature) {
    setState(() {
      status = '$feature ကို Demo အဖြစ် ရွေးထားသည်။ AI backend ချိတ်ဆက်ပြီးမှ တကယ်အလုပ်လုပ်မည်။';
    });
  }

  void requestPlan(String selected) {
    setState(() {
      plan = selected;
      status = 'Plan request: $selected။ KPay ${'09951337589'} သို့ ငွေလွှဲပြီး Admin အတည်ပြုချက်လိုအပ်သည်။ Demo က ငွေလွှဲမှုကို အလိုအလျောက် မစစ်နိုင်ပါ။';
    });
  }

  Widget featureButton(IconData icon, String title, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFF315A92)),
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(
            colors: [Color(0xFF142B4C), Color(0xFF171333)],
          ),
        ),
        child: Column(
          children: [
            Icon(icon, size: 34, color: const Color(0xFF43D8FF)),
            const SizedBox(height: 10),
            Text(title, textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('✦ My ai sai', style: TextStyle(fontWeight: FontWeight.w900)),
        backgroundColor: const Color(0xFF0B1327),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Center(child: Chip(label: Text(plan))),
          )
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  colors: [Color(0xFF075985), Color(0xFF4C1D95)],
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Your AI Media Creator', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('ဓာတ်ပုံ • စာသား • အသံ', style: TextStyle(fontSize: 16)),
                  SizedBox(height: 6),
                  Text('Demo Prototype — ဝန်ဆောင်မှုအစစ်များ မချိတ်ဆက်ရသေးပါ။'),
                ],
              ),
            ),
            const SizedBox(height: 18),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.35,
              children: [
                featureButton(Icons.image, 'Image → Video', chooseImage),
                featureButton(Icons.record_voice_over, 'Text → Voice', () => demoAction('Text → Voice')),
                featureButton(Icons.mic, 'Voice → Text', () => demoAction('Voice → Text')),
                featureButton(Icons.branding_watermark, 'My ai sai Watermark', () => demoAction('Watermark')),
              ],
            ),
            if (image != null) ...[
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('ရွေးထားသော ဓာတ်ပုံ'),
                      const SizedBox(height: 8),
                      Text(image!.name),
                      const SizedBox(height: 8),
                      const Text('မှတ်ချက်: ဒီ Demo သည် ဗီဒီယိုမထုတ်သေးပါ။ Image-to-video AI API လိုအပ်သည်။'),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 18),
            const Text('Pro Plan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Card(
              child: ListTile(
                leading: const Icon(Icons.bolt, color: Color(0xFF16C8FF), size: 32),
                title: const Text('1 လ — 30,000 ကျပ်'),
                subtitle: const Text('တစ်နေ့ ၅ ပုဒ် • တစ်ပုဒ် ၁၁ စက္ကန့်'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => requestPlan('1 လ Pro'),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.workspace_premium, color: Color(0xFFCB78FF), size: 32),
                title: const Text('2 လ — 50,000 ကျပ်'),
                subtitle: const Text('တစ်နေ့ ၆ ပုဒ် • တစ်ပုဒ် ၂၀ စက္ကန့်'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => requestPlan('2 လ Pro'),
              ),
            ),
            const SizedBox(height: 18),
            const Text('ငွေပေးချေမှု / ဆက်သွယ်ရန်', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Card(
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('KPay: 09951337589'),
                    Text('အမည်: Twetarhlaing'),
                    Text('Viber: 09675938437'),
                    SizedBox(height: 8),
                    Text('လက်ရှိ Demo တွင် အလိုအလျောက် ငွေလွှဲအတည်ပြုမှု မပါဝင်ပါ။'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF17243A),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(status),
            ),
            const SizedBox(height: 20),
            const Center(
              child: Text('My ai sai', style: TextStyle(color: Color(0xFF49D7FF), fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
